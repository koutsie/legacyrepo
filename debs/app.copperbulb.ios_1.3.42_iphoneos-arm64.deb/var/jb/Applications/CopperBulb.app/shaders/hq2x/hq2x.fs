uniform float threshold;

vec3 pixel(vec2 center, vec2 offset) {
    vec2 p = clamp(center + offset, vec2(0.5), uSourceSize - 0.5);
    return texture2D(uSource, p / uTextureSize).rgb;
}

// Colors differ when their YUV distance passes the hqx thresholds (48, 7 and 6 of 255), scaled by threshold.
bool differ(vec3 a, vec3 b) {
    mat3 toYuv = mat3(0.299, -0.169, 0.5, 0.587, -0.331, -0.419, 0.114, 0.5, -0.081);
    vec3 d = abs(toYuv * (a - b));
    return d.x > 0.188 * threshold || d.y > 0.027 * threshold || d.z > 0.024 * threshold;
}

// hq2x-style interpolation: each output pixel is a corner of a game pixel and is blended
// with the neighbors toward that corner that are similar to it, or rounded off when the
// two neighbors match each other but not the pixel.
void main() {
    vec2 texel = vTexCoord * uTextureSize;
    vec2 center = floor(texel) + 0.5;
    vec2 corner = step(0.5, fract(texel)) * 2.0 - 1.0;
    vec3 e = pixel(center, vec2(0.0));
    vec3 side = pixel(center, vec2(corner.x, 0.0));
    vec3 vertical = pixel(center, vec2(0.0, corner.y));
    vec3 diagonal = pixel(center, corner);
    bool sideDiffers = differ(e, side);
    bool verticalDiffers = differ(e, vertical);
    vec3 color = e;
    if (sideDiffers && verticalDiffers && !differ(side, vertical)) {
        color = differ(e, diagonal) ? (2.0 * e + side + vertical) * 0.25 : (6.0 * e + side + vertical) * 0.125;
    } else if (!sideDiffers && !verticalDiffers) {
        color = (6.0 * e + side + vertical) * 0.125;
    } else if (!sideDiffers) {
        color = (3.0 * e + side) * 0.25;
    } else if (!verticalDiffers) {
        color = (3.0 * e + vertical) * 0.25;
    }
    gl_FragColor = vec4(color, 1.0);
}
