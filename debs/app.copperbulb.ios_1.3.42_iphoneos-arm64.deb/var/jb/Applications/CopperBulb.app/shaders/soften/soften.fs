uniform float amount;

vec3 pixel(vec2 center, vec2 offset) {
    vec2 p = clamp(center + offset, vec2(0.5), uSourceSize - 0.5);
    return texture2D(uSource, p / uTextureSize).rgb;
}

// 3x3 binomial blur at game resolution, blended with the original pixel.
void main() {
    vec2 center = floor(vTexCoord * uTextureSize) + 0.5;
    vec3 blur = pixel(center, vec2(0.0)) * 4.0
        + (pixel(center, vec2(-1.0, 0.0)) + pixel(center, vec2(1.0, 0.0)) + pixel(center, vec2(0.0, -1.0)) + pixel(center, vec2(0.0, 1.0))) * 2.0
        + pixel(center, vec2(-1.0, -1.0)) + pixel(center, vec2(1.0, -1.0)) + pixel(center, vec2(-1.0, 1.0)) + pixel(center, vec2(1.0, 1.0));
    gl_FragColor = vec4(mix(pixel(center, vec2(0.0)), blur / 16.0, amount), 1.0);
}
