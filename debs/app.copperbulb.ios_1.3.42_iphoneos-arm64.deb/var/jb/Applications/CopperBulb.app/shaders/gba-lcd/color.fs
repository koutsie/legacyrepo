uniform float lcdGamma;
uniform float crosstalk;
uniform float saturation;
uniform float brightness;

// Approximates an unlit or front-lit LCD: a darker response curve and some
// bleed between the color channels. Runs once per game pixel.
void main() {
    vec3 color = pow(texture2D(uSource, vTexCoord).rgb, vec3(lcdGamma));
    mat3 bleed = mat3(
        0.80, 0.10, 0.06,
        0.18, 0.80, 0.20,
        0.02, 0.10, 0.74);
    color = mix(color, bleed * color, crosstalk);
    float luma = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(luma), color, saturation) * brightness;
    gl_FragColor = vec4(pow(clamp(color, 0.0, 1.0), vec3(1.0 / 2.2)), 1.0);
}
