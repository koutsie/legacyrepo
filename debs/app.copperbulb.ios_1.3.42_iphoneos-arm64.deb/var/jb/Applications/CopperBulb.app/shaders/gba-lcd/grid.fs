uniform float strength;

// Dark lines between game pixels once the scale leaves room for them.
void main() {
    vec2 scale = max(uOutputSize / uSourceSize, vec2(1.0));
    vec2 texel = vTexCoord * uTextureSize;
    vec2 base = floor(texel);
    vec2 f = texel - base - 0.5;
    vec2 region = 0.5 - 0.5 / scale;
    vec2 g = (f - clamp(f, -region, region)) * scale + 0.5;
    vec3 color = texture2D(uSource, (base + g) / uTextureSize).rgb;
    vec2 cell = fract(texel);
    vec2 edge = min(cell, 1.0 - cell) * scale;
    float line = smoothstep(0.0, 1.0, min(edge.x, edge.y));
    float fade = clamp((min(scale.x, scale.y) - 2.0) / 3.0, 0.0, 1.0);
    gl_FragColor = vec4(color * (1.0 - strength * fade * (1.0 - line)), 1.0);
}
