uniform float sharpness;

// Horizontal color bleed of a composite signal, at twice the horizontal resolution.
void main() {
    vec2 offset = vec2(0.5 / uTextureSize.x, 0.0);
    float side = 0.25 * (1.0 - sharpness);
    vec3 color = texture2D(uSource, vTexCoord).rgb * (1.0 - 2.0 * side)
        + (texture2D(uSource, vTexCoord - offset).rgb + texture2D(uSource, vTexCoord + offset).rgb) * side;
    gl_FragColor = vec4(color, 1.0);
}
