uniform float scanlines;
uniform float mask;

void main() {
    vec2 texel = vTexCoord * uTextureSize;
    // Rows stay discrete so each one reads as a beam line.
    vec3 color = texture2D(uSource, vec2(vTexCoord.x, (floor(texel.y) + 0.5) / uTextureSize.y)).rgb;
    float scale = uOutputSize.y / uSourceSize.y;
    float fade = clamp((scale - 1.5) / 2.0, 0.0, 1.0);
    float dy = fract(texel.y) - 0.5;
    float beam = exp(-dy * dy * 10.0) * 1.2;
    color *= mix(1.0, beam, scanlines * fade);
    float column = mod(floor(vTexCoord.x * uTextureSize.x / uSourceSize.x * uOutputSize.x), 3.0);
    vec3 phosphor = vec3(column < 0.5 ? 1.0 : 1.0 - mask, column >= 0.5 && column < 1.5 ? 1.0 : 1.0 - mask, column >= 1.5 ? 1.0 : 1.0 - mask);
    color *= phosphor * (1.0 + mask * 0.5);
    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
