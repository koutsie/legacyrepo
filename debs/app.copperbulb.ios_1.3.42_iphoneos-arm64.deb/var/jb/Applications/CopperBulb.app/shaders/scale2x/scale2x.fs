vec3 pixel(vec2 center, vec2 offset) {
    vec2 p = clamp(center + offset, vec2(0.5), uSourceSize - 0.5);
    return texture2D(uSource, p / uTextureSize).rgb;
}

bool same(vec3 a, vec3 b) {
    return dot(abs(a - b), vec3(1.0)) < 0.004;
}

// Scale2x (EPX): each output pixel is one corner of a game pixel. The corner takes the
// neighbor color when the two neighbors that touch it match and the opposite ones do not.
void main() {
    vec2 texel = vTexCoord * uTextureSize;
    vec2 center = floor(texel) + 0.5;
    vec2 corner = step(0.5, fract(texel)) * 2.0 - 1.0;
    vec3 e = pixel(center, vec2(0.0));
    vec3 side = pixel(center, vec2(corner.x, 0.0));
    vec3 vertical = pixel(center, vec2(0.0, corner.y));
    vec3 sideOpposite = pixel(center, vec2(-corner.x, 0.0));
    vec3 verticalOpposite = pixel(center, vec2(0.0, -corner.y));
    bool rounded = same(side, vertical) && !same(vertical, sideOpposite) && !same(side, verticalOpposite);
    gl_FragColor = vec4(rounded ? side : e, 1.0);
}
