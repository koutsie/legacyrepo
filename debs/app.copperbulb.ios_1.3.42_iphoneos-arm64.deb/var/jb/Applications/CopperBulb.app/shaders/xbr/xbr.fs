uniform float blend;

vec3 pixel(vec2 center, vec2 offset) {
    vec2 p = clamp(center + offset, vec2(0.5), uSourceSize - 0.5);
    return texture2D(uSource, p / uTextureSize).rgb;
}

float diff(vec3 a, vec3 b) {
    return dot(abs(a - b), vec3(0.299, 0.587, 0.114));
}

// Level 1 xBR edge rule, written per output corner. With the corner direction s, f and h are
// the two neighbors touching the corner and i is the diagonal. The color changes less along
// the f-h diagonal than across it when an edge runs there; the corner then takes the closer neighbor.
void main() {
    vec2 texel = vTexCoord * uTextureSize;
    vec2 center = floor(texel) + 0.5;
    vec2 s = step(0.5, fract(texel)) * 2.0 - 1.0;
    vec3 e = pixel(center, vec2(0.0));
    vec3 f = pixel(center, vec2(s.x, 0.0));
    vec3 h = pixel(center, vec2(0.0, s.y));
    vec3 i = pixel(center, s);
    vec3 b = pixel(center, vec2(0.0, -s.y));
    vec3 d = pixel(center, vec2(-s.x, 0.0));
    vec3 c = pixel(center, vec2(s.x, -s.y));
    vec3 g = pixel(center, vec2(-s.x, s.y));
    vec3 f4 = pixel(center, vec2(2.0 * s.x, 0.0));
    vec3 h5 = pixel(center, vec2(0.0, 2.0 * s.y));
    vec3 i4 = pixel(center, vec2(2.0 * s.x, s.y));
    vec3 i5 = pixel(center, vec2(s.x, 2.0 * s.y));
    float along = diff(e, c) + diff(e, g) + diff(i, f4) + diff(i, h5) + 4.0 * diff(h, f);
    float across = diff(h, d) + diff(h, i5) + diff(f, i4) + diff(f, b) + 4.0 * diff(e, i);
    bool edge = along < across && diff(e, f) > 0.01 && diff(e, h) > 0.01;
    vec3 neighbor = diff(e, f) <= diff(e, h) ? f : h;
    gl_FragColor = vec4(edge ? mix(e, neighbor, blend) : e, 1.0);
}
